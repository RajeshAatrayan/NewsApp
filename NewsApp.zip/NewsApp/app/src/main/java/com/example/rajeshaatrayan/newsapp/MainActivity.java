package com.example.rajeshaatrayan.newsapp;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView sign = (TextView) findViewById(R.id.signature);
        Typeface typeface = Typeface.createFromAsset(getAssets(), "font/BaronNeueBlackItalic.otf");
        sign.setTypeface(typeface);
    }

    public void onBusinessButtonClick(View view) {
        Intent intent = new Intent(MainActivity.this, BusinessActivity.class);
        startActivity(intent);
    }

    public void onEducationButtonClick(View view) {
        Intent intent = new Intent(MainActivity.this, EducationActivity.class);
        startActivity(intent);
    }

    public void onLifeStyleButtonClick(View view) {
        Intent intent = new Intent(MainActivity.this, LifeStyleActivity.class);
        startActivity(intent);
    }

    public void onMediaButtonClick(View view) {
        Intent intent = new Intent(MainActivity.this, MediaActivity.class);
        startActivity(intent);
    }

    public void onPoliticsButtonClick(View view) {
        Intent intent = new Intent(MainActivity.this, PoliticsActivity.class);
        startActivity(intent);
    }

    public void onSportsButtonClick(View view) {
        Intent intent = new Intent(MainActivity.this, SportsActivity.class);
        startActivity(intent);
    }

    public void onTechnologyButtonClick(View view) {
        Intent intent = new Intent(MainActivity.this, TechnologyActivity.class);
        startActivity(intent);
    }
}
