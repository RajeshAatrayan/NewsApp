package com.example.rajeshaatrayan.newsapp;

/**
 * Created by RajeshAatrayan on 22-06-2018.
 */

public class Articles {
    private String mSection;
    private String mHeadLines;
    private String mDate;
    private String intenURL;

    Articles(String mSection, String mHeadLines, String intenURL, String mDate) {
        this.mSection = mSection;
        this.intenURL = intenURL;
        this.mDate = mDate;
        this.mHeadLines = mHeadLines;
    }

    public String getmSection() {
        return mSection;
    }

    public String getmHeadLines() {
        return mHeadLines;
    }

    public String getmDate() {
        return mDate;
    }

    public String getIntenURL() {
        return intenURL;
    }

}
