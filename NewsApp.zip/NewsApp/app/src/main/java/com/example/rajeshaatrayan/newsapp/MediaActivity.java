package com.example.rajeshaatrayan.newsapp;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MediaActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<Articles>> {

    private static String MEDIA_REQUEST_URL = "https://content.guardianapis.com/media?page-size=10&api-key=2410a627-cada-4b5e-aa59-ea762775a44c";
    private static final int MEDIA_LOADER_ID = 1;
    private ArticleAdapter mAdapter;
    private TextView emptyView;
    private ProgressBar progressBar;
    private ImageView nosignal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview);
        ListView commonListView = (ListView) findViewById(R.id.listview);
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        emptyView = (TextView) findViewById(R.id.empty_view);
        progressBar = (ProgressBar) findViewById(R.id.pbar);
        nosignal = (ImageView) findViewById(R.id.nosignal);
        nosignal.setVisibility(View.GONE);
        if (networkInfo != null && networkInfo.isConnected()) {
            LoaderManager loaderManager = getLoaderManager();
            loaderManager.initLoader(MEDIA_LOADER_ID, null, this);
        } else {
            progressBar.setVisibility(View.GONE);
            nosignal.setVisibility(View.VISIBLE);
        }
        int color = R.color.mediaColor;
        mAdapter = new ArticleAdapter(MediaActivity.this, new ArrayList<Articles>(), color);
        commonListView.setAdapter(mAdapter);
        commonListView.setEmptyView(emptyView);
        commonListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Articles object = mAdapter.getItem(i);
                Uri uri = Uri.parse(object.getIntenURL());
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
    }

    public Loader<List<Articles>> onCreateLoader(int i, Bundle bundle) {
        return new ArticleLoader(this, MEDIA_REQUEST_URL);
    }

    public void onLoadFinished(Loader<List<Articles>> loader, List<Articles> articlesObtained) {
        progressBar.setVisibility(View.GONE);
        nosignal.setVisibility(View.GONE);
        emptyView.setText(R.string.no_articles);
        mAdapter.clear();
        if (articlesObtained != null && !articlesObtained.isEmpty()) {
            mAdapter.addAll(articlesObtained);
        }
    }

    public void onLoaderReset(Loader<List<Articles>> loader) {
        // Loader reset, so we can clear out our existing data.
        mAdapter.clear();
    }
}
