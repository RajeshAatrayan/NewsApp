package com.example.rajeshaatrayan.newsapp;

import android.content.AsyncTaskLoader;
import android.content.Context;

import java.util.List;

/**
 * Created by RajeshAatrayan on 22-06-2018.
 */

public class ArticleLoader extends AsyncTaskLoader<List<Articles>> {
    private String mURL;

    public ArticleLoader(Context context, String url) {
        super(context);
        mURL = url;
    }

    protected void onStartLoading() {
        forceLoad();
    }

    @Override
    public List<Articles> loadInBackground() {
        if (mURL == null) return null;
        List<Articles> listArticles = QueryUtils.fetchArticleData(mURL);
        return listArticles;
    }
}
