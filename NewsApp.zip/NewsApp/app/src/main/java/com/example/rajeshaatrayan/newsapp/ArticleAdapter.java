package com.example.rajeshaatrayan.newsapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by RajeshAatrayan on 22-06-2018.
 */

public class ArticleAdapter extends ArrayAdapter<Articles> {
    private int bgColor;

    public ArticleAdapter(@NonNull Context context, ArrayList<Articles> articles, int color) {
        super(context, 0, articles);
        bgColor = color;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.article_list, parent, false);
        }
        Articles currentArticle = getItem(position);
        TextView businessView = (TextView) listItemView.findViewById(R.id.business_view);
        businessView.setBackgroundColor(bgColor);
        TextView headlinesView = (TextView) listItemView.findViewById(R.id.headlines_view);
        TextView dateView = (TextView) listItemView.findViewById(R.id.date_view);
        TextView author = (TextView) listItemView.findViewById(R.id.author);
        author.setText(currentArticle.getmAuthor());
        businessView.setText(currentArticle.getmSection());
        headlinesView.setText(currentArticle.getmHeadLines());
        dateView.setText(currentArticle.getmDate());
        return listItemView;
    }

}

